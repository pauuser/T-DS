#ifndef H_CORRECT_FUNC
#define H_CORRECT_FUNC

int check_float_string(char *str);

int check_int_string(char *str, int *m);

int mantissa_of_zeroes(char *mnt);

#endif
