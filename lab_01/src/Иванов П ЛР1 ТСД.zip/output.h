#ifndef H_OUTPUT_FUNC
#define H_OUTPUT_FUNC

void welcome_print(void);

void print_error(int rc);

#endif
