#ifndef H_INPUT_FUNC
#define H_CORRECT_FUNC

int input_float(long_num *real_num);

int input_integer(long_num *int_num);

#endif
